package com.git_test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GitTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
